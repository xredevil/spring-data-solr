var myapp = angular.module('letterAvatarApp', ['ngLetterAvatar']);

